package com.von.classlock.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.von.classlock.MainActivity
import com.von.classlock.R
import com.von.classlock.data.AppDatabase
import com.von.classlock.util.TimeUtils
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first

/**
 * Foreground service that monitors the current time and
 * launches the app when a class starts.
 */
class ClassMonitorService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var monitorJob: Job? = null

    companion object {
        const val CHANNEL_ID = "class_monitor_channel"
        const val NOTIFICATION_ID = 1001
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, buildNotification("Monitoring timetable..."))
        startMonitoring()
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        monitorJob?.cancel()
        serviceScope.cancel()
        super.onDestroy()
    }

    private fun startMonitoring() {
        monitorJob?.cancel()
        monitorJob = serviceScope.launch {
            var lastSubjectId: Long? = null

            while (isActive) {
                try {
                    val db = AppDatabase.getDatabase(applicationContext)
                    val slots = db.timetableDao().getAllSlots().first()
                    val subjects = db.subjectDao().getAllSubjects().first()
                    val info = TimeUtils.getCurrentSlot(slots, subjects)

                    when {
                        info.isAngelus -> {
                            updateNotification("🙏 Angelus — Time for prayer")
                            // Optionally open the app to show Angelus
                            openApp()
                        }
                        info.isInClass && info.subject != null -> {
                            val subjectName = info.subject.shortName
                            updateNotification("📚 Class Mode: $subjectName (${info.remainingMinutes} min left)")

                            // If a new class just started, open the app
                            if (info.subject.id != lastSubjectId) {
                                openApp()
                                lastSubjectId = info.subject.id
                            }
                        }
                        info.isBreak -> {
                            updateNotification("☕ Break Time — Free to use phone")
                            lastSubjectId = null
                        }
                        else -> {
                            updateNotification("Von's ClassLock is monitoring")
                            lastSubjectId = null
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }

                delay(30_000) // Check every 30 seconds
            }
        }
    }

    private fun openApp() {
        val intent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
        }
        startActivity(intent)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Class Monitoring",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows current class status"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(content: String): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Von's ClassLock")
            .setContentText(content)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setSilent(true)
            .build()
    }

    private fun updateNotification(content: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification(content))
    }
}
