package com.von.classlock.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.von.classlock.data.model.CurrentClassInfo
import com.von.classlock.data.model.SecurityType
import com.von.classlock.ui.viewmodel.MainViewModel
import com.von.classlock.util.TimeUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    viewModel: MainViewModel,
    onRequestAccessibility: () -> Unit
) {
    val currentInfo by viewModel.currentInfo.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val isUnlocked by viewModel.isUnlocked.collectAsState()
    val subjects by viewModel.subjects.collectAsState()

    var showUnlockDialog by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var selectedTab by remember { mutableIntStateOf(0) }

    // Angelus takes highest priority
    if (currentInfo.isAngelus) {
        AngelusScreen()
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Von's ClassLock", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White,
                    actionIconContentColor = Color.White
                ),
                actions = {
                    IconButton(onClick = { showSettings = true }) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.Home, contentDescription = null) },
                    label = { Text("Now") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.CalendarMonth, contentDescription = null) },
                    label = { Text("Timetable") }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.MenuBook, contentDescription = null) },
                    label = { Text("Materials") }
                )
            }
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding).fillMaxSize()) {
            when (selectedTab) {
                0 -> CurrentStatusScreen(
                    info = currentInfo,
                    isUnlocked = isUnlocked,
                    onUnlockRequest = {
                        if (settings?.securityType == SecurityType.NONE) {
                            viewModel.unlockTemporarily()
                        } else {
                            showUnlockDialog = true
                        }
                    }
                )
                1 -> TimetableScreen(viewModel = viewModel)
                2 -> MaterialsScreen(viewModel = viewModel)
            }
        }
    }

    if (showUnlockDialog) {
        UnlockDialog(
            securityType = settings?.securityType ?: SecurityType.PIN,
            onDismiss = { showUnlockDialog = false },
            onUnlock = { input ->
                if (viewModel.verifyCredential(input)) {
                    viewModel.unlockTemporarily()
                    showUnlockDialog = false
                }
            }
        )
    }

    if (showSettings) {
        SettingsScreen(
            viewModel = viewModel,
            onDismiss = { showSettings = false },
            onRequestAccessibility = onRequestAccessibility
        )
    }
}

@Composable
fun CurrentStatusScreen(
    info: CurrentClassInfo,
    isUnlocked: Boolean,
    onUnlockRequest: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        when {
            info.isInClass && info.subject != null -> {
                // CLASS MODE
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1565C0)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "CLASS MODE",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = info.subject.name,
                            color = Color.White,
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "${TimeUtils.formatTime(info.slot!!.startHour, info.slot.startMinute)} – ${TimeUtils.formatTime(info.slot.endHour, info.slot.endMinute)}",
                            color = Color.White.copy(alpha = 0.9f),
                            fontSize = 16.sp
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "${info.remainingMinutes} minutes remaining",
                            color = Color.White,
                            fontSize = 18.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(32.dp))

                Text(
                    text = "Only ${info.subject.shortName} materials are available",
                    style = MaterialTheme.typography.bodyLarge,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(24.dp))

                if (isUnlocked) {
                    Text(
                        text = "Temporarily unlocked",
                        color = Color(0xFF2E7D32),
                        fontWeight = FontWeight.Medium
                    )
                } else {
                    OutlinedButton(onClick = onUnlockRequest) {
                        Icon(Icons.Default.LockOpen, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Unlock temporarily")
                    }
                }
            }

            info.isBreak -> {
                // BREAK
                Icon(
                    Icons.Default.FreeBreakfast,
                    contentDescription = null,
                    modifier = Modifier.size(72.dp),
                    tint = Color(0xFF558B2F)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = info.slot?.label ?: "Break",
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "You can use your phone freely",
                    style = MaterialTheme.typography.bodyLarge
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "${info.remainingMinutes} min left",
                    color = MaterialTheme.colorScheme.primary
                )
            }

            else -> {
                // FREE TIME
                Icon(
                    Icons.Default.CheckCircle,
                    contentDescription = null,
                    modifier = Modifier.size(72.dp),
                    tint = Color(0xFF2E7D32)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Free Time",
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "No class right now.\nYou can use your phone freely.",
                    style = MaterialTheme.typography.bodyLarge,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
fun AngelusScreen() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1A237E)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(32.dp)
        ) {
            Text(
                text = "🙏",
                fontSize = 48.sp
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "The Angelus",
                color = Color.White,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "The Angel of the Lord declared unto Mary,\nAnd she conceived of the Holy Spirit.\n\nHail Mary, full of grace...\n\nBehold the handmaid of the Lord.\nBe it done unto me according to thy word.\n\nAnd the Word was made flesh.\nAnd dwelt among us.\n\nPray for us, O holy Mother of God.\nThat we may be made worthy of the promises of Christ.",
                color = Color.White.copy(alpha = 0.95f),
                fontSize = 15.sp,
                textAlign = TextAlign.Center,
                lineHeight = 22.sp
            )
        }
    }
}

@Composable
fun UnlockDialog(
    securityType: SecurityType,
    onDismiss: () -> Unit,
    onUnlock: (String) -> Unit
) {
    var input by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Enter ${if (securityType == SecurityType.PIN) "PIN" else "Password"}") },
        text = {
            Column {
                OutlinedTextField(
                    value = input,
                    onValueChange = {
                        input = it
                        error = false
                    },
                    label = { Text(if (securityType == SecurityType.PIN) "4-digit PIN" else "Password") },
                    singleLine = true,
                    isError = error
                )
                if (error) {
                    Text("Incorrect. Try again.", color = MaterialTheme.colorScheme.error)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onUnlock(input)
                // If still showing, it failed
                error = true
            }) {
                Text("Unlock")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
