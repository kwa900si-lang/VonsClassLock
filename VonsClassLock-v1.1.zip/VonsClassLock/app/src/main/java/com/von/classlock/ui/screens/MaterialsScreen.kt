package com.von.classlock.ui.screens

import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.von.classlock.data.model.Material
import com.von.classlock.data.model.Subject
import com.von.classlock.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MaterialsScreen(viewModel: MainViewModel) {
    val context = LocalContext.current
    val subjects by viewModel.subjects.collectAsState()
    val currentInfo by viewModel.currentInfo.collectAsState()
    val materials by viewModel.materials.collectAsState()
    val isUnlocked by viewModel.isUnlocked.collectAsState()
    val forcedSubject = if (currentInfo.isInClass && currentInfo.subject != null && !isUnlocked) currentInfo.subject else null
    var selectedSubject by remember { mutableStateOf<Subject?>(null) }
    var addMenu by remember { mutableStateOf(false) }
    var noteDialog by remember { mutableStateOf(false) }
    var noteTitle by remember { mutableStateOf("") }
    var noteBody by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(forcedSubject, subjects) {
        val target = forcedSubject ?: selectedSubject ?: subjects.firstOrNull()
        if (target != null) { selectedSubject = target; viewModel.loadMaterialsForSubject(target.id) }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            val subject = forcedSubject ?: selectedSubject
            if (subject == null) message = "Select a subject first." else {
                try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: SecurityException) { }
                val title = context.contentResolver.query(uri, null, null, null, null)?.use { c ->
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (c.moveToFirst() && i >= 0) c.getString(i) else null
                } ?: "Learning material"
                val mime = context.contentResolver.getType(uri).orEmpty()
                val type = when {
                    mime == "application/pdf" -> "pdf"
                    mime.startsWith("image/") -> "image"
                    mime.startsWith("video/") -> "video"
                    mime.startsWith("audio/") -> "audio"
                    else -> "file"
                }
                viewModel.addMaterial(subject.id, title, uri.toString(), type)
            }
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        if (forcedSubject != null) {
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Text("Showing only ${forcedSubject.name} materials (Class Mode)", Modifier.padding(12.dp), fontWeight = FontWeight.Medium)
            }
            Spacer(Modifier.height(12.dp))
        } else {
            var expanded by remember { mutableStateOf(false) }
            ExposedDropdownMenuBox(expanded, { expanded = it }) {
                OutlinedTextField(selectedSubject?.name ?: "Select subject", {}, readOnly = true,
                    label = { Text("Subject") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                    modifier = Modifier.fillMaxWidth().menuAnchor())
                ExposedDropdownMenu(expanded, { expanded = false }) {
                    subjects.forEach { s -> DropdownMenuItem(text = { Text(s.name) }, onClick = {
                        selectedSubject = s; viewModel.loadMaterialsForSubject(s.id); expanded = false
                    }) }
                }
            }
            Spacer(Modifier.height(12.dp))
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Learning materials", style = MaterialTheme.typography.titleMedium)
            Box {
                FilledTonalButton(onClick = { addMenu = true }, enabled = (forcedSubject ?: selectedSubject) != null) {
                    Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Add material")
                }
                DropdownMenu(addMenu, { addMenu = false }) {
                    DropdownMenuItem(
                        text = { Text("Upload PDF / Image / Video") },
                        leadingIcon = { Icon(Icons.Default.PictureAsPdf, null) },
                        onClick = {
                            addMenu = false
                            picker.launch(arrayOf(
                                "application/pdf",
                                "image/*",
                                "video/*",
                                "audio/*",
                                "text/plain"
                            ))
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Write a note") },
                        leadingIcon = { Icon(Icons.Default.Description, null) },
                        onClick = {
                            addMenu = false
                            noteTitle = ""
                            noteBody = ""
                            noteDialog = true
                        }
                    )
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        if (materials.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text("No materials uploaded yet.\n\nTap + Add material to upload a PDF or write notes.", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(materials, key = { it.id }) { item ->
                MaterialCard(item, onOpen = {
                    if (item.fileType == "note") {
                        message = item.filePath
                    } else {
                        try {
                            val mime = when (item.fileType) {
                                "pdf" -> "application/pdf"
                                "image" -> "image/*"
                                "video" -> "video/*"
                                "audio" -> "audio/*"
                                else -> "*/*"
                            }
                            context.startActivity(
                                Intent(Intent.ACTION_VIEW)
                                    .setDataAndType(Uri.parse(item.filePath), mime)
                                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            )
                        } catch (_: Exception) {
                            message = "Unable to open this file. Install a PDF/video player or the permission may have expired."
                        }
                    }
                }, onDelete = { viewModel.deleteMaterial(item) })
            }
        }
    }

    if (noteDialog) AlertDialog(onDismissRequest = { noteDialog = false }, title = { Text("Create learning note") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(noteTitle, { noteTitle = it }, label = { Text("Note title") }, singleLine = true)
            OutlinedTextField(noteBody, { noteBody = it }, label = { Text("Write your note") }, minLines = 4)
        } }, confirmButton = { TextButton(enabled = noteTitle.isNotBlank() && noteBody.isNotBlank(), onClick = {
            (forcedSubject ?: selectedSubject)?.let { viewModel.addMaterial(it.id, noteTitle.trim(), noteBody, "note") }
            noteDialog = false
        }) { Text("Save") } }, dismissButton = { TextButton(onClick = { noteDialog = false }) { Text("Cancel") } })

    message?.let { text -> AlertDialog(onDismissRequest = { message = null }, title = { Text("Learning material") },
        text = { Text(text) }, confirmButton = { TextButton(onClick = { message = null }) { Text("OK") } }) }
}

@Composable
fun MaterialCard(material: Material, onOpen: () -> Unit, onDelete: () -> Unit) {
    val icon = when (material.fileType) {
        "note" -> Icons.Default.Description
        "pdf" -> Icons.Default.PictureAsPdf
        "image" -> Icons.Default.Image
        "video" -> Icons.Default.Videocam
        else -> Icons.Default.Description
    }
    Card(modifier = Modifier.fillMaxWidth(), onClick = onOpen) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(material.title, fontWeight = FontWeight.Medium)
                Text(
                    material.fileType.uppercase(),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "Delete")
            }
        }
    }
}
