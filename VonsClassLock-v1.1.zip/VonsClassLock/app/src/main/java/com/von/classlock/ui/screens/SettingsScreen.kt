package com.von.classlock.ui.screens

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.von.classlock.data.model.SecurityType
import com.von.classlock.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    onDismiss: () -> Unit,
    onRequestAccessibility: () -> Unit
) {
    val settings by viewModel.settings.collectAsState()
    val context = LocalContext.current

    var showPinSetup by remember { mutableStateOf(false) }
    var showPasswordSetup by remember { mutableStateOf(false) }
    var showRemoveConfirm by remember { mutableStateOf(false) }
    var removeError by remember { mutableStateOf<String?>(null) }

    // Permission status (recomputed when screen is shown)
    val isAccessibilityEnabled = remember { isAccessibilityServiceEnabled(context) }
    val isBatteryOptimizationIgnored = remember { isIgnoringBatteryOptimizations(context) }
    val canScheduleExactAlarms = remember { canScheduleExactAlarms(context) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // ---------- PERMISSIONS CHECKLIST ----------
            Text(
                "Permissions Checklist",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                "These must be enabled for the app to work properly. Tap a button to open the system setting.",
                style = MaterialTheme.typography.bodyMedium
            )

            PermissionRow(
                title = "Accessibility Service (Required)",
                description = "Keeps the app in front during class so you stay focused.",
                isGranted = isAccessibilityEnabled,
                buttonText = if (isAccessibilityEnabled) "Enabled ✓" else "Enable now",
                onClick = onRequestAccessibility
            )

            PermissionRow(
                title = "Battery Optimization",
                description = "Prevents Android from killing the monitoring service.",
                isGranted = isBatteryOptimizationIgnored,
                buttonText = if (isBatteryOptimizationIgnored) "Ignored ✓" else "Allow unrestricted",
                onClick = {
                    try {
                        val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                            data = Uri.parse("package:${context.packageName}")
                        }
                        context.startActivity(intent)
                    } catch (e: Exception) {
                        // Fallback
                        val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                        context.startActivity(intent)
                    }
                }
            )

            PermissionRow(
                title = "Exact Alarms / Notifications",
                description = "Needed so the app can open itself when a class starts.",
                isGranted = canScheduleExactAlarms,
                buttonText = if (canScheduleExactAlarms) "Allowed ✓" else "Open settings",
                onClick = {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
                        context.startActivity(intent)
                    } else {
                        val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                            putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                        }
                        context.startActivity(intent)
                    }
                }
            )

            Divider()

            // ---------- SECURITY ----------
            Text("Security", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(
                "Current: ${
                    when (settings?.securityType) {
                        SecurityType.PIN -> "4-digit PIN"
                        SecurityType.PASSWORD -> "Password"
                        else -> "None"
                    }
                }",
                style = MaterialTheme.typography.bodyMedium
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { showPinSetup = true }) {
                    Text("Set PIN")
                }
                OutlinedButton(onClick = { showPasswordSetup = true }) {
                    Text("Set Password")
                }
                if (settings?.securityType != SecurityType.NONE) {
                    TextButton(onClick = {
                        removeError = null
                        showRemoveConfirm = true
                    }) {
                        Text("Remove")
                    }
                }
            }

            Divider()

            // ---------- ABOUT ----------
            Text("About", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("Von's ClassLock v1.0")
            Text("St. John's School, Sekondi — 3SCI1")
            Text("Built to help you stay focused during class hours.")
        }
    }

    // Set PIN dialog
    if (showPinSetup) {
        CredentialSetupDialog(
            title = "Set 4-digit PIN",
            isPin = true,
            onDismiss = { showPinSetup = false },
            onConfirm = { pin ->
                viewModel.setSecurity(SecurityType.PIN, pin)
                showPinSetup = false
            }
        )
    }

    // Set Password dialog
    if (showPasswordSetup) {
        CredentialSetupDialog(
            title = "Set Password",
            isPin = false,
            onDismiss = { showPasswordSetup = false },
            onConfirm = { password ->
                viewModel.setSecurity(SecurityType.PASSWORD, password)
                showPasswordSetup = false
            }
        )
    }

    // Confirm Remove dialog — REQUIRES current PIN/Password
    if (showRemoveConfirm) {
        var input by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showRemoveConfirm = false },
            title = { Text("Confirm Remove Security") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Enter your current ${if (settings?.securityType == SecurityType.PIN) "PIN" else "password"} to remove it."
                    )
                    OutlinedTextField(
                        value = input,
                        onValueChange = {
                            input = it
                            removeError = null
                        },
                        label = {
                            Text(if (settings?.securityType == SecurityType.PIN) "Current PIN" else "Current Password")
                        },
                        singleLine = true,
                        isError = removeError != null
                    )
                    removeError?.let {
                        Text(it, color = MaterialTheme.colorScheme.error)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (viewModel.verifyCredential(input)) {
                        viewModel.setSecurity(SecurityType.NONE, "")
                        showRemoveConfirm = false
                    } else {
                        removeError = "Incorrect. Try again."
                    }
                }) {
                    Text("Remove")
                }
            },
            dismissButton = {
                TextButton(onClick = { showRemoveConfirm = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun PermissionRow(
    title: String,
    description: String,
    isGranted: Boolean,
    buttonText: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (isGranted)
                Color(0xFFE8F5E9)
            else
                Color(0xFFFFF3E0)
        )
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = if (isGranted) Icons.Default.CheckCircle else Icons.Default.Warning,
                    contentDescription = null,
                    tint = if (isGranted) Color(0xFF2E7D32) else Color(0xFFE65100)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(title, fontWeight = FontWeight.SemiBold)
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(description, style = MaterialTheme.typography.bodySmall)
            Spacer(modifier = Modifier.height(8.dp))
            Button(
                onClick = onClick,
                enabled = !isGranted,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(buttonText)
            }
        }
    }
}

@Composable
fun CredentialSetupDialog(
    title: String,
    isPin: Boolean,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var value by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = value,
                    onValueChange = { value = it },
                    label = { Text(if (isPin) "PIN" else "Password") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = confirm,
                    onValueChange = { confirm = it },
                    label = { Text("Confirm") },
                    singleLine = true
                )
                error?.let {
                    Text(it, color = MaterialTheme.colorScheme.error)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                when {
                    isPin && (value.length != 4 || !value.all { it.isDigit() }) -> {
                        error = "PIN must be exactly 4 digits"
                    }
                    value != confirm -> {
                        error = "Values do not match"
                    }
                    value.isBlank() -> {
                        error = "Cannot be empty"
                    }
                    else -> onConfirm(value)
                }
            }) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

// ---------- Helper functions ----------

private fun isAccessibilityServiceEnabled(context: Context): Boolean {
    val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
    val enabledServices = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_GENERIC)
    return enabledServices.any { it.resolveInfo.serviceInfo.packageName == context.packageName }
}

private fun isIgnoringBatteryOptimizations(context: Context): Boolean {
    val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
    return pm.isIgnoringBatteryOptimizations(context.packageName)
}

private fun canScheduleExactAlarms(context: Context): Boolean {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager
        am.canScheduleExactAlarms()
    } else {
        true
    }
}
