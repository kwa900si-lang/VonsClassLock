package com.von.classlock.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.von.classlock.service.ClassMonitorService

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED ||
            intent?.action == "android.intent.action.QUICKBOOT_POWERON"
        ) {
            // Restart the monitoring service after reboot
            val serviceIntent = Intent(context, ClassMonitorService::class.java)
            context.startForegroundService(serviceIntent)
        }
    }
}
