package com.von.classlock

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.von.classlock.service.ClassMonitorService
import com.von.classlock.ui.screens.MainScreen
import com.von.classlock.ui.theme.VonsClassLockTheme
import com.von.classlock.ui.viewmodel.MainViewModel
import com.von.classlock.ui.viewmodel.MainViewModelFactory

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Start the monitoring service
        startService(Intent(this, ClassMonitorService::class.java))

        setContent {
            VonsClassLockTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    val viewModel: MainViewModel = viewModel(
                        factory = MainViewModelFactory(
                            (application as ClassLockApp).database
                        )
                    )
                    MainScreen(
                        viewModel = viewModel,
                        onRequestAccessibility = { openAccessibilitySettings() }
                    )
                }
            }
        }
    }

    private fun openAccessibilitySettings() {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        startActivity(intent)
    }
}
