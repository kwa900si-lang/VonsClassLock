package com.von.classlock

import android.app.Application
import com.von.classlock.data.AppDatabase

class ClassLockApp : Application() {
    val database: AppDatabase by lazy { AppDatabase.getDatabase(this) }
}
