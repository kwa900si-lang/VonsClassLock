package com.von.classlock.util

import java.security.MessageDigest

object SecurityUtils {

    fun hash(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun verify(input: String, storedHash: String?): Boolean {
        if (storedHash == null) return false
        return hash(input) == storedHash
    }
}
