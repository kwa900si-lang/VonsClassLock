package com.von.classlock.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.von.classlock.data.dao.MaterialDao
import com.von.classlock.data.dao.SettingsDao
import com.von.classlock.data.dao.SubjectDao
import com.von.classlock.data.dao.TimetableDao
import com.von.classlock.data.model.AppSettings
import com.von.classlock.data.model.Material
import com.von.classlock.data.model.Subject
import com.von.classlock.data.model.TimetableSlot
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [Subject::class, TimetableSlot::class, Material::class, AppSettings::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun subjectDao(): SubjectDao
    abstract fun timetableDao(): TimetableDao
    abstract fun materialDao(): MaterialDao
    abstract fun settingsDao(): SettingsDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "vons_classlock.db"
                )
                    .addCallback(PrepopulateCallback())
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class PrepopulateCallback : Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    CoroutineScope(Dispatchers.IO).launch {
                        // Insert subjects
                        database.subjectDao().insertAll(TimetableData.subjects)

                        // Insert timetable slots
                        database.timetableDao().insertAll(TimetableData.getAllSlots())

                        // Default settings
                        database.settingsDao().insert(AppSettings())
                    }
                }
            }
        }
    }
}
