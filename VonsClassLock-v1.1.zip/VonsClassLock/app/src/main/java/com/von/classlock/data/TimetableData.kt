package com.von.classlock.data

import com.von.classlock.data.model.SlotType
import com.von.classlock.data.model.Subject
import com.von.classlock.data.model.TimetableSlot

/**
 * Pre-loaded data for St. John's School, Sekondi - 3SCI1
 * Based on the timetable provided by the user.
 */
object TimetableData {

    val subjects = listOf(
        Subject(id = 1, name = "Elective Mathematics", shortName = "E/MATS", colorHex = "#E65100"),
        Subject(id = 2, name = "Mathematics", shortName = "MATS", colorHex = "#EF6C00"),
        Subject(id = 3, name = "Chemistry", shortName = "CHEM", colorHex = "#2E7D32"),
        Subject(id = 4, name = "Biology", shortName = "BIO", colorHex = "#1565C0"),
        Subject(id = 5, name = "Physics", shortName = "PHY", colorHex = "#6A1B9A"),
        Subject(id = 6, name = "French", shortName = "FRE", colorHex = "#C62828"),
        Subject(id = 7, name = "English Language", shortName = "ENG", colorHex = "#00838F"),
        Subject(id = 8, name = "Social Studies", shortName = "SOC", colorHex = "#4527A0"),
        Subject(id = 9, name = "Physical Education", shortName = "PE", colorHex = "#558B2F"),
        Subject(id = 10, name = "Library", shortName = "LIB", colorHex = "#5D4037"),
        Subject(id = 11, name = "SBA / T-TEL", shortName = "SBA", colorHex = "#37474F")
    )

    /**
     * Full weekly timetable slots
     * dayOfWeek: 1=Monday ... 5=Friday
     */
    fun getAllSlots(): List<TimetableSlot> {
        val slots = mutableListOf<TimetableSlot>()

        // Helper to add a class block
        fun addClass(day: Int, startH: Int, startM: Int, endH: Int, endM: Int, subjectId: Long) {
            slots.add(
                TimetableSlot(
                    dayOfWeek = day,
                    startHour = startH,
                    startMinute = startM,
                    endHour = endH,
                    endMinute = endM,
                    subjectId = subjectId,
                    slotType = SlotType.CLASS
                )
            )
        }

        fun addBreak(day: Int, startH: Int, startM: Int, endH: Int, endM: Int, label: String) {
            slots.add(
                TimetableSlot(
                    dayOfWeek = day,
                    startHour = startH,
                    startMinute = startM,
                    endHour = endH,
                    endMinute = endM,
                    subjectId = null,
                    slotType = SlotType.BREAK,
                    label = label
                )
            )
        }

        fun addAngelus(day: Int) {
            slots.add(
                TimetableSlot(
                    dayOfWeek = day,
                    startHour = 12,
                    startMinute = 0,
                    endHour = 12,
                    endMinute = 5,
                    subjectId = null,
                    slotType = SlotType.ANGELUS,
                    label = "Angelus"
                )
            )
        }

        // ========== MONDAY ==========
        addClass(1, 7, 30, 9, 30, 1)      // E/MATS
        addBreak(1, 9, 30, 10, 0, "First Break")
        addClass(1, 10, 0, 12, 0, 3)      // CHEM
        addAngelus(1)
        addClass(1, 12, 5, 13, 0, 7)      // ENG
        addBreak(1, 13, 0, 13, 30, "Second Break")
        addClass(1, 13, 30, 15, 30, 5)    // PHY

        // ========== TUESDAY ==========
        addClass(2, 7, 30, 9, 30, 4)      // BIO
        addBreak(2, 9, 30, 10, 0, "First Break")
        addClass(2, 10, 0, 12, 0, 6)      // FRE
        addAngelus(2)
        addClass(2, 12, 5, 13, 0, 9)      // PE
        addBreak(2, 13, 0, 13, 30, "Second Break")
        addClass(2, 13, 30, 15, 30, 7)    // ENG

        // ========== WEDNESDAY ==========
        addClass(3, 7, 30, 9, 30, 3)      // CHEM
        addBreak(3, 9, 30, 10, 0, "First Break")
        addClass(3, 10, 0, 12, 0, 11)     // SBA / T-TEL
        addAngelus(3)
        addClass(3, 12, 5, 13, 0, 7)      // ENG
        addBreak(3, 13, 0, 13, 30, "Second Break")
        addClass(3, 13, 30, 15, 30, 2)    // MATS

        // ========== THURSDAY ==========
        addClass(4, 7, 30, 9, 30, 4)      // BIO
        addBreak(4, 9, 30, 10, 0, "First Break")
        addClass(4, 10, 0, 12, 0, 8)      // SOC
        addAngelus(4)
        addClass(4, 12, 5, 13, 0, 2)      // MATS
        addBreak(4, 13, 0, 13, 30, "Second Break")
        addClass(4, 13, 30, 15, 30, 6)    // FRE

        // ========== FRIDAY ==========
        addClass(5, 7, 30, 9, 30, 1)      // E/MATS
        addBreak(5, 9, 30, 10, 0, "First Break")
        addClass(5, 10, 0, 12, 0, 5)      // PHY
        addAngelus(5)
        addClass(5, 12, 5, 13, 0, 10)     // LIB
        addBreak(5, 13, 0, 13, 30, "Second Break")
        addClass(5, 13, 30, 15, 30, 2)    // MATS

        return slots
    }
}
