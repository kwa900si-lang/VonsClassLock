package com.von.classlock.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.von.classlock.data.model.SlotType
import com.von.classlock.data.model.Subject
import com.von.classlock.data.model.TimetableSlot
import com.von.classlock.ui.viewmodel.MainViewModel
import com.von.classlock.util.TimeUtils

@Composable
fun TimetableScreen(viewModel: MainViewModel) {
    val slots by viewModel.allSlots.collectAsState()
    val subjects by viewModel.subjects.collectAsState()
    val currentDay = TimeUtils.getCurrentDayOfWeek()

    val days = listOf("Mon", "Tue", "Wed", "Thu", "Fri")
    var selectedDay by remember { mutableIntStateOf(if (currentDay in 1..5) currentDay else 1) }

    Column(modifier = Modifier.fillMaxSize()) {
        // Day selector
        ScrollableTabRow(
            selectedTabIndex = selectedDay - 1,
            edgePadding = 8.dp
        ) {
            days.forEachIndexed { index, day ->
                Tab(
                    selected = selectedDay == index + 1,
                    onClick = { selectedDay = index + 1 },
                    text = {
                        Text(
                            text = day,
                            fontWeight = if (selectedDay == index + 1) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                )
            }
        }

        val daySlots = slots.filter { it.dayOfWeek == selectedDay }
            .sortedBy { TimeUtils.toMinutes(it.startHour, it.startMinute) }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(daySlots) { slot ->
                TimetableSlotCard(slot = slot, subjects = subjects)
            }
        }
    }
}

@Composable
fun TimetableSlotCard(slot: TimetableSlot, subjects: List<Subject>) {
    val subject = subjects.find { it.id == slot.subjectId }
    val backgroundColor = when (slot.slotType) {
        SlotType.CLASS -> Color(android.graphics.Color.parseColor(subject?.colorHex ?: "#1976D2")).copy(alpha = 0.15f)
        SlotType.BREAK -> Color(0xFFE8F5E9)
        SlotType.ANGELUS -> Color(0xFFE8EAF6)
    }
    val accentColor = when (slot.slotType) {
        SlotType.CLASS -> Color(android.graphics.Color.parseColor(subject?.colorHex ?: "#1976D2"))
        SlotType.BREAK -> Color(0xFF2E7D32)
        SlotType.ANGELUS -> Color(0xFF3949AB)
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = backgroundColor)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Time
            Column(modifier = Modifier.width(70.dp)) {
                Text(
                    text = TimeUtils.formatTime(slot.startHour, slot.startMinute),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = accentColor
                )
                Text(
                    text = TimeUtils.formatTime(slot.endHour, slot.endMinute),
                    fontSize = 13.sp,
                    color = Color.Gray
                )
            }

            // Vertical accent bar
            Box(
                modifier = Modifier
                    .width(4.dp)
                    .height(40.dp)
                    .background(accentColor, RoundedCornerShape(2.dp))
            )

            Spacer(modifier = Modifier.width(14.dp))

            // Content
            Column {
                when (slot.slotType) {
                    SlotType.CLASS -> {
                        Text(
                            text = subject?.name ?: "Unknown",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 16.sp
                        )
                        Text(
                            text = subject?.shortName ?: "",
                            fontSize = 13.sp,
                            color = Color.Gray
                        )
                    }
                    SlotType.BREAK -> {
                        Text(
                            text = slot.label,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 16.sp,
                            color = accentColor
                        )
                    }
                    SlotType.ANGELUS -> {
                        Text(
                            text = "🙏 Angelus",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 16.sp,
                            color = accentColor
                        )
                    }
                }
            }
        }
    }
}
