package com.von.classlock.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Represents a school subject
 */
@Entity(tableName = "subjects")
data class Subject(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,                    // e.g. "Physics", "Chemistry"
    val shortName: String,               // e.g. "PHY", "CHEM"
    val colorHex: String = "#1976D2"     // Color for UI
)

/**
 * A single class period in the weekly timetable
 */
@Entity(tableName = "timetable_slots")
data class TimetableSlot(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dayOfWeek: Int,                  // 1 = Monday ... 5 = Friday
    val startHour: Int,
    val startMinute: Int,
    val endHour: Int,
    val endMinute: Int,
    val subjectId: Long?,                // null for breaks / Angelus
    val slotType: SlotType,              // CLASS, BREAK, ANGELUS
    val label: String = ""               // e.g. "First Break", "Angelus"
)

enum class SlotType {
    CLASS,
    BREAK,
    ANGELUS
}

/**
 * Learning material uploaded by the user
 */
@Entity(tableName = "materials")
data class Material(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subjectId: Long,
    val title: String,
    val filePath: String,                // Local path to the PDF/image/etc
    val fileType: String,                // "pdf", "image", "video", "note"
    val addedAt: Long = System.currentTimeMillis()
)

/**
 * App settings (PIN / Password)
 */
@Entity(tableName = "settings")
data class AppSettings(
    @PrimaryKey val id: Int = 1,
    val securityType: SecurityType = SecurityType.NONE,
    val pinHash: String? = null,
    val passwordHash: String? = null,
    val isLockingEnabled: Boolean = true
)

enum class SecurityType {
    NONE,
    PIN,
    PASSWORD
}

/**
 * Helper data class for current status
 */
data class CurrentClassInfo(
    val isInClass: Boolean,
    val subject: Subject?,
    val slot: TimetableSlot?,
    val remainingMinutes: Int = 0,
    val isBreak: Boolean = false,
    val isAngelus: Boolean = false
)
