package com.von.classlock.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.von.classlock.data.AppDatabase
import com.von.classlock.data.model.*
import com.von.classlock.util.SecurityUtils
import com.von.classlock.util.TimeUtils
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MainViewModel(private val db: AppDatabase) : ViewModel() {

    private val _currentInfo = MutableStateFlow(
        CurrentClassInfo(isInClass = false, subject = null, slot = null)
    )
    val currentInfo: StateFlow<CurrentClassInfo> = _currentInfo.asStateFlow()

    val subjects: StateFlow<List<Subject>> = db.subjectDao().getAllSubjects()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allSlots: StateFlow<List<TimetableSlot>> = db.timetableDao().getAllSlots()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val settings: StateFlow<AppSettings?> = db.settingsDao().getSettings()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val selectedSubjectId = MutableStateFlow<Long?>(null)
    val materials: StateFlow<List<Material>> = selectedSubjectId
        .filterNotNull()
        .flatMapLatest { subjectId -> db.materialDao().getMaterialsForSubject(subjectId) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _isUnlocked = MutableStateFlow(false)
    val isUnlocked: StateFlow<Boolean> = _isUnlocked.asStateFlow()

    init {
        // Continuously update current class status
        viewModelScope.launch {
            while (true) {
                val slots = allSlots.value
                val subs = subjects.value
                if (slots.isNotEmpty() && subs.isNotEmpty()) {
                    _currentInfo.value = TimeUtils.getCurrentSlot(slots, subs)
                }
                delay(15_000)
            }
        }
    }

    fun loadMaterialsForSubject(subjectId: Long) {
        selectedSubjectId.value = subjectId
    }

    fun addMaterial(subjectId: Long, title: String, filePath: String, fileType: String) {
        viewModelScope.launch {
            db.materialDao().insert(
                Material(
                    subjectId = subjectId,
                    title = title,
                    filePath = filePath,
                    fileType = fileType
                )
            )
        }
    }

    fun deleteMaterial(material: Material) {
        viewModelScope.launch {
            db.materialDao().delete(material)
        }
    }

    fun setSecurity(type: SecurityType, credential: String) {
        viewModelScope.launch {
            val current = db.settingsDao().getSettingsOnce() ?: AppSettings()
            val updated = when (type) {
                SecurityType.PIN -> current.copy(
                    securityType = SecurityType.PIN,
                    pinHash = SecurityUtils.hash(credential),
                    passwordHash = null
                )
                SecurityType.PASSWORD -> current.copy(
                    securityType = SecurityType.PASSWORD,
                    passwordHash = SecurityUtils.hash(credential),
                    pinHash = null
                )
                SecurityType.NONE -> current.copy(
                    securityType = SecurityType.NONE,
                    pinHash = null,
                    passwordHash = null
                )
            }
            db.settingsDao().insert(updated)
        }
    }

    fun verifyCredential(input: String): Boolean {
        val s = settings.value ?: return true
        return when (s.securityType) {
            SecurityType.PIN -> SecurityUtils.verify(input, s.pinHash)
            SecurityType.PASSWORD -> SecurityUtils.verify(input, s.passwordHash)
            SecurityType.NONE -> true
        }
    }

    fun unlockTemporarily() {
        _isUnlocked.value = true
        // Auto re-lock after 2 minutes
        viewModelScope.launch {
            delay(120_000)
            _isUnlocked.value = false
        }
    }

    fun lockAgain() {
        _isUnlocked.value = false
    }
}

class MainViewModelFactory(private val db: AppDatabase) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return MainViewModel(db) as T
    }
}
