package com.von.classlock.util

import com.von.classlock.data.model.CurrentClassInfo
import com.von.classlock.data.model.SlotType
import com.von.classlock.data.model.Subject
import com.von.classlock.data.model.TimetableSlot
import java.util.Calendar

object TimeUtils {

    /**
     * Returns the current day of week as 1=Monday ... 7=Sunday
     */
    fun getCurrentDayOfWeek(): Int {
        val cal = Calendar.getInstance()
        val day = cal.get(Calendar.DAY_OF_WEEK)
        // Calendar: Sunday=1, Monday=2 ... Saturday=7
        // We want: Monday=1 ... Sunday=7
        return if (day == Calendar.SUNDAY) 7 else day - 1
    }

    fun getCurrentHour(): Int = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    fun getCurrentMinute(): Int = Calendar.getInstance().get(Calendar.MINUTE)

    /**
     * Converts hour+minute to total minutes since midnight
     */
    fun toMinutes(hour: Int, minute: Int): Int = hour * 60 + minute

    /**
     * Finds the current active slot (class, break, or Angelus)
     */
    fun getCurrentSlot(
        slots: List<TimetableSlot>,
        subjects: List<Subject>
    ): CurrentClassInfo {
        val day = getCurrentDayOfWeek()
        if (day > 5) {
            // Weekend
            return CurrentClassInfo(isInClass = false, subject = null, slot = null)
        }

        val now = toMinutes(getCurrentHour(), getCurrentMinute())
        val todaySlots = slots.filter { it.dayOfWeek == day }

        for (slot in todaySlots) {
            val start = toMinutes(slot.startHour, slot.startMinute)
            val end = toMinutes(slot.endHour, slot.endMinute)

            if (now in start until end) {
                val remaining = end - now
                return when (slot.slotType) {
                    SlotType.CLASS -> {
                        val subject = subjects.find { it.id == slot.subjectId }
                        CurrentClassInfo(
                            isInClass = true,
                            subject = subject,
                            slot = slot,
                            remainingMinutes = remaining
                        )
                    }
                    SlotType.BREAK -> CurrentClassInfo(
                        isInClass = false,
                        subject = null,
                        slot = slot,
                        remainingMinutes = remaining,
                        isBreak = true
                    )
                    SlotType.ANGELUS -> CurrentClassInfo(
                        isInClass = false,
                        subject = null,
                        slot = slot,
                        remainingMinutes = remaining,
                        isAngelus = true
                    )
                }
            }
        }

        return CurrentClassInfo(isInClass = false, subject = null, slot = null)
    }

    /**
     * Format time as HH:mm
     */
    fun formatTime(hour: Int, minute: Int): String {
        return String.format("%02d:%02d", hour, minute)
    }

    fun formatDuration(minutes: Int): String {
        val h = minutes / 60
        val m = minutes % 60
        return if (h > 0) "${h}h ${m}m" else "${m}m"
    }
}
