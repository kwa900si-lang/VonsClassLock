package com.von.classlock.data.dao

import androidx.room.*
import com.von.classlock.data.model.AppSettings
import com.von.classlock.data.model.Material
import com.von.classlock.data.model.Subject
import com.von.classlock.data.model.TimetableSlot
import kotlinx.coroutines.flow.Flow

@Dao
interface SubjectDao {
    @Query("SELECT * FROM subjects ORDER BY name")
    fun getAllSubjects(): Flow<List<Subject>>

    @Query("SELECT * FROM subjects WHERE id = :id")
    suspend fun getSubjectById(id: Long): Subject?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(subjects: List<Subject>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(subject: Subject): Long
}

@Dao
interface TimetableDao {
    @Query("SELECT * FROM timetable_slots ORDER BY dayOfWeek, startHour, startMinute")
    fun getAllSlots(): Flow<List<TimetableSlot>>

    @Query("SELECT * FROM timetable_slots WHERE dayOfWeek = :day ORDER BY startHour, startMinute")
    suspend fun getSlotsForDay(day: Int): List<TimetableSlot>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(slots: List<TimetableSlot>)

    @Query("DELETE FROM timetable_slots")
    suspend fun clearAll()
}

@Dao
interface MaterialDao {
    @Query("SELECT * FROM materials WHERE subjectId = :subjectId ORDER BY addedAt DESC")
    fun getMaterialsForSubject(subjectId: Long): Flow<List<Material>>

    @Query("SELECT * FROM materials ORDER BY addedAt DESC")
    fun getAllMaterials(): Flow<List<Material>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(material: Material): Long

    @Delete
    suspend fun delete(material: Material)

    @Query("DELETE FROM materials WHERE id = :id")
    suspend fun deleteById(id: Long)
}

@Dao
interface SettingsDao {
    @Query("SELECT * FROM settings WHERE id = 1")
    fun getSettings(): Flow<AppSettings?>

    @Query("SELECT * FROM settings WHERE id = 1")
    suspend fun getSettingsOnce(): AppSettings?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(settings: AppSettings)
}
