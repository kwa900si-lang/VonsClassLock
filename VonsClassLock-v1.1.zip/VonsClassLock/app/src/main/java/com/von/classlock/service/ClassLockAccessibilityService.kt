package com.von.classlock.service

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import com.von.classlock.MainActivity
import com.von.classlock.data.AppDatabase
import com.von.classlock.util.TimeUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * Medium-strict locking service.
 * When a class is active, if the user leaves the app, this service
 * immediately brings Von's ClassLock back to the front.
 */
class ClassLockAccessibilityService : AccessibilityService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var isInClassMode = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        // Start monitoring
        startPeriodicCheck()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        // Only react to window changes
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
        ) {
            checkAndBringBack()
        }
    }

    override fun onInterrupt() {
        // Required override
    }

    private fun startPeriodicCheck() {
        serviceScope.launch {
            while (true) {
                updateClassModeStatus()
                kotlinx.coroutines.delay(15_000) // Check every 15 seconds
            }
        }
    }

    private suspend fun updateClassModeStatus() {
        try {
            val db = AppDatabase.getDatabase(applicationContext)
            val slots = db.timetableDao().getAllSlots().first()
            val subjects = db.subjectDao().getAllSubjects().first()
            val info = TimeUtils.getCurrentSlot(slots, subjects)
            isInClassMode = info.isInClass
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun checkAndBringBack() {
        if (!isInClassMode) return

        val currentPackage = rootInActiveWindow?.packageName?.toString()
        val myPackage = packageName

        // If the user is not in our app, bring it back
        if (currentPackage != null && currentPackage != myPackage) {
            bringAppToFront()
        }
    }

    private fun bringAppToFront() {
        val intent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
            addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        startActivity(intent)
    }
}
