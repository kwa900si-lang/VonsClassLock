# Von's ClassLock

**Strict timetable focus app for Android**  
Built for St. John's School, Sekondi — Class 3SCI1

## Features

- **Pre-loaded real timetable** (Monday–Friday) with exact period times
- **Class Mode**: During a subject period, only that subject's materials are available
- **Medium-strict locking**: Accessibility Service keeps bringing the app back if you try to leave during class
- **Angelus support**: At 12:00–12:05 the app displays the Holy Angelus prayer
- **Break times**: Full free access during First Break, Second Break, and free periods
- **Security**: Optional 4-digit PIN or password to temporarily unlock during class
- **Material upload**: Upload your own PDFs and notes, organized by subject
- **Auto-start**: App opens itself when a class begins
- **Survives reboot**: Monitoring service restarts after phone restart

## Period Times

| Period          | Time          |
|-----------------|---------------|
| Period 1        | 7:30 – 8:30   |
| Period 2        | 8:30 – 9:30   |
| First Break     | 9:30 – 10:00  |
| Period 3        | 10:00 – 11:00 |
| Period 4        | 11:00 – 12:00 |
| Angelus         | 12:00 – 12:05 |
| Period 5        | 12:05 – 1:00  |
| Second Break    | 1:00 – 1:30   |
| Period 6        | 1:30 – 2:30   |
| Period 7        | 2:30 – 3:30   |

## Technical Stack

- Kotlin + Jetpack Compose
- Room Database
- Foreground Service + Accessibility Service
- Min SDK 26 (Android 8.0)

## How to Build

1. Open the project in Android Studio
2. Sync Gradle
3. Run on a device or emulator (Android 8.0+)

## First-time Setup on Phone

1. Install the app
2. Open **Settings → Accessibility** and enable **Von's ClassLock**
3. (Recommended) Disable battery optimization for the app
4. Optionally set a PIN or Password in the app Settings

## Important Notes

- The locking is **medium-strict**. A determined user can still force-stop the app from system Settings.
- The Accessibility Service must be enabled manually (Android requirement).
- This app is designed to help you stay disciplined, not to be 100% unbreakable.

## Adding learning materials

Open **Materials** and choose a subject. Tap **+ Add material**:
- **Upload PDF or file** opens Android's document picker. Choose a PDF, text file, or image.
- **Write a note** creates a note stored inside the app.

Tap a saved file to open it with a compatible app. Tap a saved note to read it. Use the trash icon to delete an item.

The app stores the selected document URI and requests persistent read access from Android. If a document provider does not grant persistent access, the file may need to be selected again after its provider revokes access.

## Cloud build (no PC required)

The repository includes `.github/workflows/android.yml`. Push the project to a GitHub repository, then open **Actions → Build Android APK → Run workflow**. When the workflow completes, download the `VonsClassLock-debug` artifact. The APK is inside that artifact.

A debug APK is for testing and is not a Play Store release.
